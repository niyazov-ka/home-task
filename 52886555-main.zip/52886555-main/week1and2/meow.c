#include <stdio.h>

int main(void)
{
    int i = 0;
    while (i<5)
    {
        printf("Meow \n");
        i++;
    }
}